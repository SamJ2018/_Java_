package com.cys.dao;

import com.cys.annotation.MySelect;
import com.cys.pojo.User;

import java.util.List;

/**
 * @author missb
 * @create 2020--04--01 4:44 PM
 */

public interface IUserDao {

    /**
     * 查询所有接口
     */
    @MySelect("select * from userInfo")
    List<User> findAll();
}
