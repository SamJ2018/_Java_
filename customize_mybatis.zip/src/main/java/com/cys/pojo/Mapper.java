package com.cys.pojo;

/**
 * @author missb
 * @create 2020--04--01 10:21 AM
 *
 * 用于封装查询时的必要信息：
 *      要执行的SQL语句和实体类的权限定类名
 * */

public class Mapper {

    /**SQL*/
    private String queryString;

   /**结果类型的全限定类名*/
   private String resultType;

    public String getQueryString() {
        return queryString;
    }

    public void setQueryString(String queryString) {
        this.queryString = queryString;
    }

    public String getResultType() {
        return resultType;
    }

    public void setResultType(String resultType) {
        this.resultType = resultType;
    }
}
