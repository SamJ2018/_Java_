package com.cys;

import com.cys.dao.IUserDao;
import com.cys.factory.SqlSessionFactory;
import com.cys.factory.SqlSessionFactoryBuilder;
import com.cys.parse.SqlSession;
import com.cys.pojo.User;
import com.cys.utils.share.Resources;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * 测试mybatis环境
 *
 * @author missb
 * @create 2020--04--01 4:46 PM
 */

public class MybatisTest {
    public static void main(String[] args) throws IOException {
        //1.读取配置文件
        InputStream in = Resources.getResourceAsStream("SqlMapConfig.xml");

        //2.创建SqlSessionFactory的构建者对象
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();

        //3.使用构建者创建工场对象 SqlSessionFactory
        SqlSessionFactory factory = builder.build(in);

        //4.使用SqlSessionFactory生产SqlSession对象
        SqlSession session = factory.openSession();

        //5.使用SqlSession创建dao接口的代理对象
        IUserDao userDao = session.getMapper(IUserDao.class);

        //6.使用代理对象执行查询所有方法
        List<User> users = userDao.findAll();

        for (User user : users) {
            System.out.println(user);
        }

        session.close();
        in.close();
    }
}
