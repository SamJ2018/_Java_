package com.cys.annotation;

import java.lang.annotation.*;

/**
 * @author missb
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface MySelect {
    String value();
}
