package com.cys.parse;

/**
 * 操作数据库的核心对象
 *
 * @author missb
 * @create 2020--04--01 2:25 PM
 */

public interface SqlSession {
    /**
     * @param daoClass 传入的dao对象
     * @param <T> 代理对象类型
     * @return 返回代理对象
     */
    <T> T getMapper(Class<T> daoClass);

    /**
     * 释放资源
     */
    void close();
}
