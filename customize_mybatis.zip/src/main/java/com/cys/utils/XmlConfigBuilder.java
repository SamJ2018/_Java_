package com.cys.utils;

import com.cys.annotation.MySelect;
import com.cys.parse.DefaultSqlSession;
import com.cys.pojo.Configuration;
import com.cys.pojo.Mapper;
import com.cys.utils.share.Resources;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用于解析配置文件
 *
 * @author missb
 * @create 2020--04--01 10:31 AM
 */

public class XmlConfigBuilder {
    /**
     * 解析主配置文件，将里面的内容填充到 DefaultSqlSession 需要的地方
     *
     * @param session 连接信息
     * @param config  dom4j + xpath
     */
    public static void loadConfiguration(DefaultSqlSession session, InputStream config) {
        try {
            //定义封装连接信息的配置对象（mybatis配置对象）
            Configuration cfg = new Configuration();

            //1.获取SAXReader对象
            SAXReader reader = new SAXReader();

            //2.根据字节输入流获取Document对象
            Document document = reader.read(config);

            //3.获取根节点
            Element root = document.getRootElement();

            //4.使用xpath选择指定节点的方式，获取所有property
            List<Element> propertyElements = root.selectNodes("//property");

            //5.遍历节点
            for (Element propertyElement : propertyElements) {
                //判断节点是连接数据库的哪部分信息
                //取出name属性的值
                String name = propertyElement.attributeValue("name");
                if ("driver".equals(name)) {
                    String driver = propertyElement.attributeValue("value");
                    cfg.setDriver(driver);
                }
                if ("url".equals(name)) {
                    //表示连接字符串
                    //获取property标签value属性值
                    String url = propertyElement.attributeValue("value");
                    cfg.setUrl(url);
                }
                if ("username".equals(name)) {
                    //表示用户名
                    //获取property标签value属性的值
                    String username = propertyElement.attributeValue("value");
                    cfg.setUsername(username);
                }
                if ("password".equals(name)) {
                    //表示密码
                    //获取property标签value属性的值
                    String password = propertyElement.attributeValue("value");
                    cfg.setPassword(password);
                }
                //取出 mappers 中的所有 mapper 标签，判断使用了 resource 还是 class 属性
                List<Element> mapperElements = root.selectNodes("//mappers/mapper");

                //遍历集合
                for (Element mapperElement : mapperElements) {
                    //判断 mapperElement 使用的是哪个属性
                    Attribute attribute = mapperElement.attribute("resource");
                    if (attribute != null) {
                        System.out.println("使用的是用户定义的XML");
                        //取出属性的值
                        //com.cys.dao.IUserDao.xml
                        String mapperPath = attribute.getValue();

                        //把映射配置文件的内容获取出来，封装成一个map
                        Map<String, Mapper> mappers = loadMapperConfiguration(mapperPath);

                        //给 configuration 中的mappers赋值
                        cfg.setMappers(mappers);
                    } else {
                        System.out.println("使用的是注解");
                        //没有resource属性，用的是注解
                        //1.获得class属性的值
                        String daoClassPath = mapperElement.attributeValue("class");
                        //2.根据daoClassPath获取封装的必要信息
                        Map<String,Mapper> mappers = loadMapperAnnotation(daoClassPath);

                        //3.给configuration中的mappers赋值
                        cfg.setMappers(mappers);
                    }
                }
                session.setCfg(cfg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                config.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 根据传入的参数，得到dao中所有被select注解标注的方法。
     * 根据方法名称和类名，以及方法上注解value属性的值，组成Mapper的必要信息
     * @param daoClassPath
     * @return
     */
    @SuppressWarnings("unchecked")
    private static Map<String, Mapper> loadMapperAnnotation(String daoClassPath) throws Exception {
        //定义返回值对象
        HashMap<String, Mapper> mappers = new HashMap<>();

        //1. 得到dao接口的字节码对象
        Class<?> daoClass = Class.forName(daoClassPath);

        //2.得到dao接口中的方法数组
        Method[] methods = daoClass.getMethods();

        //3.遍历Method数组
        for (Method method : methods) {
            //取出每一个方法，判断是否有select注解
            boolean isAnnotated = method.isAnnotationPresent(MySelect.class);
            if (isAnnotated) {
                //创建Mapper对象
                Mapper mapper = new Mapper();
                //取出注解的value属性值 sql语句
                MySelect selectAnnotation = method.getAnnotation(MySelect.class);
                String queryString = selectAnnotation.value();
                mapper.setQueryString(queryString);

                //获取当前方法的返回值，还要必须带有泛型信息
                //如 List<User>
                Type type = method.getGenericReturnType();

                //判断type是不是参数化的类型
                if (type instanceof ParameterizedType) {
                    //强转
                    ParameterizedType pType = (ParameterizedType) type;
                    //得到参数化类型中的实际类型参数
                    Type[] types = pType.getActualTypeArguments();
                    //取出第一个
                    Class domainClass = (Class) types[0];

                    //获取domainClass的类名
                    String resultType = domainClass.getName();

                    mapper.setResultType(resultType);
                }
                //组装key的信息
                //获取方法的名称
                String methodName = method.getName();
                String className = method.getDeclaringClass().getName();
                //类名.方法名
                String key = className + "." + methodName;

                //给map的赋值
                mappers.put(key,mapper);
            }
        }
        return mappers;
    }


    /**
     * 根据传入的参数，解析XML，并且封装到Map中
     *
     * @param mapperPath 用户定义的映射XMl配置文件位置
     * @return map 中包含了获取的唯一标识 （key 是由 dao 的权限的类名 和方法名 组成）
     * 以及执行所需的必要信息（value 是一个 Mapper 对象，里面存放的是执行的 SQL 语句和要封装的实体类全限定类名）
     */
    private static Map<String, Mapper> loadMapperConfiguration(String mapperPath) throws IOException {
        InputStream in = null;
        try {

            //定义返回值对象
            HashMap<String, Mapper> mappers = new HashMap<>();

            //1.根据路径获取字节输入流
            in = Resources.getResourceAsStream(mapperPath);

            //2.根据字节输入流获取Document对象
            SAXReader reader = new SAXReader();
            Document document = reader.read(in);

            //3.获取根节点
            Element root = document.getRootElement();

            //4.获取根节点的namespace属性值
            //是组成 map 中 key 的部分
            String namespace = root.attributeValue("namespace");

            //5.获取所有的select节点
            List<Element> selectElements = root.selectNodes("//select");

            //遍历获取select节点集合
            for (Element selectElement : selectElements) {
                //取出id属性的值 （组成map中key的部分）
                String id = selectElement.attributeValue("id");

                //取出resultType属性的值 （组成map中value的部分）
                String resultType = selectElement.attributeValue("resultType");

                //取出文本内容 （组成map中value的部分）
                String queryString = selectElement.getText();

                //封装Key
                String key = namespace + "." + id;

                //封装value
                Mapper mapper = new Mapper();
                mapper.setQueryString(queryString);
                mapper.setResultType(resultType);

                //把key和value封装入mappers中
                mappers.put(key, mapper);
            }
            return mappers;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            in.close();
        }
    }
}
