package com.cys.utils.share;

import java.io.InputStream;

/**
 * @author missb
 * @create 2020--04--01 11:09 AM
 * 用于读取配置文件的类
 */

public class Resources {

    public static InputStream getResourceAsStream(String xmlPath) {
        return Resources.class.getClassLoader().getResourceAsStream(xmlPath);
    }
}
