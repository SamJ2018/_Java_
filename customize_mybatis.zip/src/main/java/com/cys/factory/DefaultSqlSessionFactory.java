package com.cys.factory;

import com.cys.parse.DefaultSqlSession;
import com.cys.parse.SqlSession;
import com.cys.utils.XmlConfigBuilder;

import java.io.InputStream;

/**
 * SqlSessionFactory的实现类
 *
 * @author missb
 * @create 2020--04--01 4:24 PM
 */
public class DefaultSqlSessionFactory implements SqlSessionFactory{
    private InputStream config = null;

    public void setConfig(InputStream config) {
        this.config = config;
    }


    @Override
    public SqlSession openSession() {
        DefaultSqlSession session = new DefaultSqlSession();

        //调用工具类解析xml文件
        XmlConfigBuilder.loadConfiguration(session,config);

        return session;
    }
}
