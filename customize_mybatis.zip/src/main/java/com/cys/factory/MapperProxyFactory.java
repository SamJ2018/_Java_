package com.cys.factory;

import com.cys.parse.Executor;
import com.cys.pojo.Mapper;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.Map;

/**
 * 用于创建代理对象的增强方法
 *
 * @author missb
 * @create 2020--04--01 3:38 PM
 */

public class MapperProxyFactory implements InvocationHandler {

    private Map<String, Mapper> mappers;
    private Connection conn;

    public MapperProxyFactory(Map<String, Mapper> mappers, Connection conn) {
        this.mappers = mappers;
        this.conn = conn;
    }


    /**
     * 对当前正在执行的方法进行增强
     *      取出当前执行的方法名称
     *      取出当前执行的方法所在类
     *      拼接成key
     *      去Map中获取Value（Mapper）
     *      使用工具类Executor的selectList方法
     * @param proxy
     * @param method
     * @param args
     * @return
     * @throws Throwable
     */
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        //1.取出方法名
        String methodName = method.getName();

        //2.取出方法所在类名
        String className = method.getDeclaringClass().getName();

        //3.拼接成key
        String key = className + "." + methodName;

        //4.使用key取出mapper
        Mapper mapper = mappers.get(key);

        if (mapper == null) {
            throw new IllegalArgumentException("传入的参数有误，无法获取执行的必要条件");
        }

        //5.创建Executor对象
        Executor executor = new Executor();
        return executor.selectList(mapper,conn);
    }
}
