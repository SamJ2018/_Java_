package com.cys.factory;

import com.cys.parse.SqlSession;

/**
 * SqlSessionFactory的接口
 *
 * @author missb
 * @create 2020--04--01 4:22 PM
 */

public interface SqlSessionFactory {

    /**
     * 创建一个SqlSession对象
      * @return SqlSession对象
     */
    SqlSession openSession();
}
