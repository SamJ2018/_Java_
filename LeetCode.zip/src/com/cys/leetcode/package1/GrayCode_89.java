package com.cys.leetcode.package1;

public class GrayCode_89 {
}
