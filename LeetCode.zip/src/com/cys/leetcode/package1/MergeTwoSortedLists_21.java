package com.cys.leetcode.package1;

/**
 * Merge two sorted linked lists and return it as a new list.
 * The new list should be made by splicing together the nodes of the first two lists.
 *
 */
public class MergeTwoSortedLists_21 {
}
