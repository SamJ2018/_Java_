package com.cys.leetcode.package1;

public class SqrtX_69 {
}
