package com.cys.leetcode.package4;

public class RangeSumQueryImmutable_303 {
}
