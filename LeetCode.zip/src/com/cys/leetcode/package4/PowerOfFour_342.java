package com.cys.leetcode.package4;

public class PowerOfFour_342 {
}
