package com.cys.leetcode.package3;

public class BestMeetingPoint_296 {
}
