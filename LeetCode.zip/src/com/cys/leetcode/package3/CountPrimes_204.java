package com.cys.leetcode.package3;

public class CountPrimes_204 {
}
