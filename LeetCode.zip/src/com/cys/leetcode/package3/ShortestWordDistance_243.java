package com.cys.leetcode.package3;

public class ShortestWordDistance_243 {
}
