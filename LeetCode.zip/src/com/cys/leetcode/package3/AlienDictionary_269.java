package com.cys.leetcode.package3;

public class AlienDictionary_269 {
}
