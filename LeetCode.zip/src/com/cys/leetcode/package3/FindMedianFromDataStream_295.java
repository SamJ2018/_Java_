package com.cys.leetcode.package3;

public class FindMedianFromDataStream_295 {
}
