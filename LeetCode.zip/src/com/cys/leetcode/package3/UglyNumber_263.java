package com.cys.leetcode.package3;

public class UglyNumber_263 {
}
