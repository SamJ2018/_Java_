package com.cys.leetcode.package3;

public class PaintHouse_256 {
}
