package com.cys.leetcode.package3;

public class RectangleArea_223 {
}
