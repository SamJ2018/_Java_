package com.cys.leetcode.package3;

public class WordPattern_290 {
}
