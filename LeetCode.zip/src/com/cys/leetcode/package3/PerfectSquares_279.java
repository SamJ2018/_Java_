package com.cys.leetcode.package3;

public class PerfectSquares_279 {
}
