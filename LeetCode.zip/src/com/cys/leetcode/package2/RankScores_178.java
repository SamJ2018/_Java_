package com.cys.leetcode.package2;

public class RankScores_178 {
}
