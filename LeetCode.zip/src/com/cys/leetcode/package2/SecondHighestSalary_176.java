package com.cys.leetcode.package2;

public class SecondHighestSalary_176 {
}
