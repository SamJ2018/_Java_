package com.cys.leetcode.package2;

public class DepartmentTopThreeSalaries_185 {
}
