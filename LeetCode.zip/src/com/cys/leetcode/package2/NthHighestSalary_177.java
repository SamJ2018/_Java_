package com.cys.leetcode.package2;

public class NthHighestSalary_177 {
}
