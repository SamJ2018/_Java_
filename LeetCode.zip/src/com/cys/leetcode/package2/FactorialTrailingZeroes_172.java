package com.cys.leetcode.package2;

public class FactorialTrailingZeroes_172 {
}
