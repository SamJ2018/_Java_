create view v1 as
select `s`.`studentname` AS `studentname`, `m`.`majorname` AS `majorname`
from (`students`.`student` `s`
         join `students`.`major` `m` on ((`s`.`majorid` = `m`.`majorid`)));

