create view v2 as
select `e`.`last_name` AS `last_name`, `d`.`department_name` AS `department_name`, `j`.`job_title` AS `job_title`
from ((`myemployees`.`employees` `e` join `myemployees`.`departments` `d` on ((`e`.`department_id` = `d`.`department_id`)))
         join `myemployees`.`jobs` `j` on ((`j`.`job_id` = `e`.`job_id`)));

