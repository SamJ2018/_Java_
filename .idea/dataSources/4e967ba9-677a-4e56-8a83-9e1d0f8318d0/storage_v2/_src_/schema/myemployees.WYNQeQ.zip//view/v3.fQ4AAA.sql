create view v3 as
select avg(`e`.`salary`) AS `平均工资`, `d`.`department_name` AS `部门名`
from `myemployees`.`employees` `e`
         join `myemployees`.`departments` `d`
where (`e`.`department_id` = `d`.`department_id`)
group by `e`.`department_id`;

